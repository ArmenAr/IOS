//
//  RequestTableViewCell.swift
//  Translator
//
//  Created by Армен Арутюнян on 06/02/2019.
//  Copyright © 2019 Армен Арутюнян. All rights reserved.
//

import UIKit

class RequestTableViewCell: UITableViewCell {

    //MARK: - Outlets
    
    @IBOutlet var requestView: UIView!
    @IBOutlet var requestLabel: UILabel!
    
    //MARK: - Functions
    
    func configure() {
        self.requestView.layer.cornerRadius = 10
        self.requestView.layer.masksToBounds = true
        self.requestLabel.adjustsFontForContentSizeCategory = true
        self.requestLabel.numberOfLines = 0
    }
}
