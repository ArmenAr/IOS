//
//  ViewController.swift
//  Translator
//
//  Created by Армен Арутюнян on 28/01/2019.
//  Copyright © 2019 Армен Арутюнян. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //MARK: - Properties
    
    var service = Service()
    var messages: [Message] = []
    var requestArray = [String]()
    var responseArray = [String]()
    var newText = ""
    var keyboard = Keyboard()
    var textDidChange = InputTextView()
    var screenTV = ScreenTableView()
    let requestCellId = "RequestCell"
    let responseCellId = "ResponseCell"
    
    //MARK: - Outlets
    
    @IBOutlet weak var inputFieldTextView: UITextView!
    @IBOutlet weak var screenTableView: UITableView!
    
    //MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        createTableView()
        keyboard.startObservingKeyboard(self.view)
        textDidChange.textDidChange(inputFieldTextView, service)
        self.hideKeyboard()
        screenTV.updateTableContentInset(forTableView: screenTableView)
    }
    
    //MARK: - Table View
    
    func createTableView() {
        screenTableView.delegate = self
        screenTableView.dataSource = self
    }
    
    func addMessage(text: String, direction: Message.Direction) {
        guard let tableView = screenTableView else { return }
        
        let newIndexPath = IndexPath(row: messages.count, section: 0)
        let newMessage = Message(text: text, direction: direction)
        
        if inputFieldTextView.text != "" {
            self.messages.append(newMessage)
            tableView.insertRows(at: [newIndexPath], with: .automatic)
        }
    }
    
    //MARK: - IBActions
    
    @IBAction func licenseButton(_ sender: Any) {
        let url = URL(string: "http://translate.yandex.ru/")!
        UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }
    
    @IBAction func translateButton(_ sender: Any) {
        newText = inputFieldTextView.text
        service.translate(by: newText) { [weak self] (translateText, error ) in
            if let error = error {
                print(error.localizedDescription)
            }
            guard let translateText = translateText, let self = self else { return }
            
            self.insertNewTranslation(request: self.newText, translation: translateText)
            self.inputFieldTextView.text = ""
        }
    }
    
    func insertNewTranslation(request: String, translation: String) {
        screenTableView.performBatchUpdates({
            self.addMessage(text: request, direction: .request)
            self.addMessage(text: translation, direction: .response)
        }, completion: { completed in
            self.scrollToLastCell()
        })
    }
    
    func scrollToLastCell() {
        guard let indexPath = indexPathForLastRow() else { return }
        screenTableView.scrollToRow(at: indexPath, at: .none, animated: true)
    }
    
    func indexPathForLastRow() -> IndexPath? {
        guard messages.count > 0 else { return nil }
        return IndexPath(row: messages.count - 1, section: 0)
    }
    
}

//MARK: - Extension
extension ViewController: UITableViewDelegate {
    
}

extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return messages.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let message = messages[indexPath.row]
        switch message.direction {
        case .request:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: requestCellId, for: indexPath) as? RequestTableViewCell else {return UITableViewCell()}
            cell.configure()
            cell.requestLabel.text = message.text 
            return cell
        case .response:
            guard let cell = tableView.dequeueReusableCell(withIdentifier: responseCellId, for: indexPath) as? ResponseTableViewCell else {return UITableViewCell()}
            cell.responseLabel.text = message.text
            cell.configure()
            return cell
        }        
    }
}

extension UIViewController
{
    func hideKeyboard() {
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(UIViewController.dismissKeyboard))
        
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        view.endEditing(true)
    }
}
