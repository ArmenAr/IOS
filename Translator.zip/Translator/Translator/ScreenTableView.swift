//
//  TableView.swift
//  Translator
//
//  Created by Армен Арутюнян on 29/01/2019.
//  Copyright © 2019 Армен Арутюнян. All rights reserved.
//

import UIKit
class ScreenTableView  {
    
    func updateTableContentInset(forTableView tableView: UITableView) {
        let numberOfSections = tableView.numberOfSections
        var contentInsetTop = tableView.bounds.size.height + 100
        
        for section in 0..<numberOfSections {
            let numRows = tableView.numberOfRows(inSection: section)
            let sectionHeaderHeight = tableView.rectForHeader(inSection: section).size.height
            let sectionFooterHeight = tableView.rectForFooter(inSection: section).size.height
            contentInsetTop -= sectionHeaderHeight + sectionFooterHeight
            for i in 0..<numRows {
                let rowHeight = tableView.rectForRow(at: IndexPath(item: i, section: section)).size.height
                contentInsetTop -= rowHeight
                if contentInsetTop <= 0 {
                    contentInsetTop = 0
                    break
                }
            }
            if contentInsetTop == 0 {
                break
            }
        }
        tableView.contentInset = UIEdgeInsets(top: contentInsetTop, left: 0, bottom: 0, right: 0)
    }
}
