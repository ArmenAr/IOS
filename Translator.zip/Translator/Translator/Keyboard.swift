//
//  Keyboard.swift
//  Translator
//
//  Created by Армен Арутюнян on 28/01/2019.
//  Copyright © 2019 Армен Арутюнян. All rights reserved.
//

import UIKit

class Keyboard {
    
    var observers: [AnyObject] = []
    
    func startObservingKeyboard(_ view: UIView) {
        observers = [
        NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillShowNotification,
                                               object: nil,
                                               queue: .main) { (notification) in
                                               view.frame.origin.y = -301
        },
        NotificationCenter.default.addObserver(forName: UIResponder.keyboardWillHideNotification,
                                               object: nil, queue: .main, using: { (notification) in
                                                view.frame.origin.y = 0
        })]
    }
}
