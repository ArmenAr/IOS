//
//  InputTextView.swift
//  Translator
//
//  Created by Армен Арутюнян on 29/01/2019.
//  Copyright © 2019 Армен Арутюнян. All rights reserved.
//

import UIKit

class InputTextView {
    
    func textDidChange(_ inputTextView: UITextView, _ service: Service) {
        NotificationCenter.default.addObserver(forName: UITextView.textDidChangeNotification,
                                               object: nil,
                                               queue: .main) { (notification) in
                                                self.textDidChange(notification, inputTextView, service)
        }
    }
    func textDidChange(_ notification: Notification, _ inputTextView: UITextView, _ service: Service) {
        guard let notificationTextView = notification.object as? UITextView,
            notificationTextView == inputTextView else { return }
        service.languageDetect(by: inputTextView.text)
    }
}
