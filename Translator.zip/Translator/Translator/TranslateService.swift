//
//  TranslateService.swift
//  Translator
//
//  Created by Армен Арутюнян on 28/01/2019.
//  Copyright © 2019 Армен Арутюнян. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

class Service {
    
    //MARK: - Properties
    
    let baseUrl = "https://translate.yandex.net/api/v1.5/tr.json/"
    let api = "trnsl.1.1.20190117T140527Z.9e59d65c676999a7.8b341108e9e45a9479908a170cb4a44a7485a0b7"
    var languige = "en"
    var lang = "ru-en"
    
    //MARK: - Functions
    
    func languageDetect(by text: String) {
        let path = "detect"
        let params: Parameters = [
            "key": self.api,
            "text": text,
            "hint": "en,ru"
        ]
        Alamofire.request(self.baseUrl + path, method: .get, parameters: params).responseJSON { (response) in
            switch response.result {
            case .failure(let error):
                print(error.localizedDescription)
            case .success(let value):
                let json = JSON(value)
                self.languige = json["lang"].stringValue
                if self.languige == "ru" {
                    self.lang = "ru-en"
                } else if self.languige == "en" {
                    self.lang = "en-ru"
                }
            }
        }
    }
    
    func translate(by text: String, completion: ((String?, Error?) -> Void)? = nil) {
        let path = "translate"
        let params: Parameters = [
            "key": self.api,
            "text": text,
            "lang": self.lang
        ]
        Alamofire.request(self.baseUrl + path, method: .get, parameters: params).responseJSON { (response) in
            switch response.result {
            case .failure(let error):
                print(error.localizedDescription)
            case .success(let value):
                let json = JSON(value)
                let translateText = json["text"][0].stringValue
                completion?(translateText, nil)
            }
        }
    }
}
