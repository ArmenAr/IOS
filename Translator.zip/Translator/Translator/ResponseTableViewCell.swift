//
//  TableViewCell.swift
//  Translator
//
//  Created by Армен Арутюнян on 28/01/2019.
//  Copyright © 2019 Армен Арутюнян. All rights reserved.
//

import UIKit

class ResponseTableViewCell: UITableViewCell {

    //MARK: - Outlets
    @IBOutlet var responseLabel: UILabel!
    @IBOutlet var responseView: UIView!

    //MARK: - Functions
    
    func configure() {
        self.responseView.layer.cornerRadius = 10
        self.responseView.layer.masksToBounds = true
    self.responseLabel.adjustsFontForContentSizeCategory = true
        self.responseLabel.numberOfLines = 0
    
    }
}
