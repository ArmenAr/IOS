//
//  Text.swift
//  Translator
//
//  Created by Армен Арутюнян on 07/02/2019.
//  Copyright © 2019 Армен Арутюнян. All rights reserved.
//

import Foundation

struct Message {
    
    enum Direction {
        case request
        case response
    }
    
    let text: String
    let direction: Direction
    
}
