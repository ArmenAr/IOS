//
//  RealmChanges.swift
//  VK APP
//
//  Created by Армен Арутюнян on 23.10.2018.
//  Copyright © 2018 Армен Арутюнян. All rights reserved.
//

import UIKit

extension IndexPath {
    static func fromRow(_ row: Int) -> IndexPath {
        return IndexPath(row: row, section: 0)
    }
}

extension UITableView {
    func applyChanges(deletions: [Int], insertions: [Int], updates: [Int]) {
        beginUpdates()
        deleteRows(at: deletions.map(IndexPath.fromRow), with: .automatic)
        insertRows(at: insertions.map(IndexPath.fromRow), with: .automatic)
        reloadRows(at: updates.map(IndexPath.fromRow), with: .automatic)
        endUpdates()
    }
}

class ApplyTableViewChanges: Operation {
    
    let tableView: UITableView
    let deletions: [Int]
    let insertions: [Int]
    let updates: [Int]
    
    init(tableView: UITableView, deletions: [Int], insertions: [Int], updates: [Int]) {
        self.tableView = tableView
        self.deletions = deletions
        self.insertions = insertions
        self.updates = updates
        super.init()
    }
    
    override func main() {
        tableView.beginUpdates()
        tableView.deleteRows(at: deletions.map(IndexPath.fromRow), with: .automatic)
        tableView.insertRows(at: insertions.map(IndexPath.fromRow), with: .automatic)
        tableView.reloadRows(at: updates.map(IndexPath.fromRow), with: .automatic)
        tableView.endUpdates()
    }
}
