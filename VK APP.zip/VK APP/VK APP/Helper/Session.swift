//
//  Session.swift
//  VK APP
//
//  Created by Армен Арутюнян on 02.10.2018.
//  Copyright © 2018 Армен Арутюнян. All rights reserved.
//

import Foundation

class Session {
    
    static let shared = Session()
    
    private init() {}
    
    var token = ""
    var userId = 0
    
}
