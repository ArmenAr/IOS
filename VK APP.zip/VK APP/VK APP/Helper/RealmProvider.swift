//
//  RealmProvider.swift
//  VK APP
//
//  Created by Армен Арутюнян on 23.10.2018.
//  Copyright © 2018 Армен Арутюнян. All rights reserved.
//

import Foundation
import RealmSwift

class RealmProvider {
    static var configuration: Realm.Configuration {
        return Realm.Configuration(deleteRealmIfMigrationNeeded: true)
    }
    
    static func saveToDatabase<T: Object>(items: [T], update: Bool = true) {
        do {
            let realm = try Realm(configuration: RealmProvider.configuration)
            
            try realm.write {
                realm.add(items, update: update)
            }
            
        } catch {
            print(error.localizedDescription)
        }
    }
    
    static func get<T: Object>(_ type: T.Type, in realm: Realm = try! Realm(configuration: RealmProvider.configuration)) -> Results<T> {
//        print(realm.configuration.fileURL!)
        return realm.objects(type)
    }
}
