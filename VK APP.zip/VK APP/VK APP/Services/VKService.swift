//
//  VKService.swift
//  VK APP
//
//  Created by Армен Арутюнян on 09.10.2018.
//  Copyright © 2018 Армен Арутюнян. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

class VKSesvice {
    func loadUserFriendsAlamofire(completion: (([Users]?, Error?) -> Void)? = nil) {
        
        let path = "friends.get"
        
        let params: Parameters = [
            "access_token": Session.shared.token,
            "order": "hints",
            "fields": "photo_100, online, last_seen",
            "v": apiVersion
        ]
        
        Alamofire.request(baseUrl + path, method: .get, parameters: params).responseJSON { (response) in
            switch response.result {
            case .failure(let error):
                completion?(nil, error)
            case .success(let value):
                let json = JSON(value)
                let friends = json["response"]["items"].arrayValue.map { Users(json: $0) }
                completion?(friends, nil)
            }
        }
    }
    func loadUserPhotoAlamofire(userId: Int, completion: (([Photo]?, Error?) -> Void)? = nil){
        let path = "photos.getAll"
        var params: Parameters = [
            "access_token": Session.shared.token,
            "count": 100,
            "v": apiVersion
        ]
        if (userId != 0) {
            params["owner_id"] = userId
        }
        Alamofire.request(baseUrl + path, method: .get, parameters: params).responseJSON { (response) in
            switch response.result {
            case .failure(let error):
                completion?(nil, error)
            case .success(let value):
                let json = JSON(value)
//                print(Alamofire.request(baseUrl + path, method: .get, parameters: params))
                let photo = json["response"]["items"].arrayValue.map { Photo(json: $0) }
                completion?(photo, nil)
            }
        }
    }
    func loadUserGroupsAlamofire(completion: (([Groups]?, Error?) -> Void)? = nil) {
        
        let path = "groups.get"
        
        let params: Parameters = [
            "access_token": Session.shared.token,
            "extended": "1",
            "fields": "members_count",
            "v": apiVersion
        ]
        
        Alamofire.request(baseUrl + path, method: .get, parameters: params).responseJSON { (response) in
            switch response.result {
            case .failure(let error):
                completion?(nil, error)
            case .success(let value):
                let json = JSON(value)
                let groups = json["response"]["items"].arrayValue.map { Groups(json: $0) }
                completion?(groups, nil)
            }
        }
    }
    func searchGroupsAlamofire(by searhText: String,completion: (([Groups]?, Error?) -> Void)? = nil) {
        let path = "groups.search"
        let params: Parameters = [
            "access_token": Session.shared.token,
            "q": searhText,
            "v": apiVersion
        ]
        Alamofire.request(baseUrl + path, method: .get, parameters: params).responseJSON { (response) in
            switch response.result {
            case .failure(let error):
                print(error.localizedDescription)
            case .success(let value):
                let json = JSON(value)
                let groups = json["response"]["items"].arrayValue.map { Groups(json: $0) }
                completion?(groups, nil)
            }
        }
    }
    func loadNews(completion: (([News]?, Error?) -> Void)? = nil){
        let path = "newsfeed.get"
        let params: Parameters = [
            "access_token": Session.shared.token,
            "filters": "post,photo",
            "v": apiVersion
        ]
        Alamofire.request(baseUrl + path, method: .get, parameters: params).responseJSON { (response) in
            switch response.result {
            case .failure(let error):
                print(error.localizedDescription)
            case .success(let value):
                let json = JSON(value)
                let news = json["response"]["items"].arrayValue.map { News(json: $0) }
                completion?(news, nil)
            }
        }
    }
    func loadNewsGroups(completion: (([NewsGroup]?, Error?) -> Void)? = nil){
        let path = "newsfeed.get"
        let params: Parameters = [
            "access_token": Session.shared.token,
            "filters": "post,photo",
            "v": apiVersion
        ]
        Alamofire.request(baseUrl + path, method: .get, parameters: params).responseJSON { (response) in
            switch response.result {
            case .failure(let error):
                print(error.localizedDescription)
            case .success(let value):
                let json = JSON(value)
                let groups = json["response"]["groups"].arrayValue.map { NewsGroup(json: $0) }
                completion?(groups, nil)
            }
        }
    }
    func loadNewsFriends(completion: (([NewsFriends]?, Error?) -> Void)? = nil){
        let path = "newsfeed.get"
        let params: Parameters = [
            "access_token": Session.shared.token,
            "filters": "post,photo",
            "v": apiVersion
        ]
        Alamofire.request(baseUrl + path, method: .get, parameters: params).responseJSON { (response) in
            switch response.result {
            case .failure(let error):
                print(error.localizedDescription)
            case .success(let value):
                let json = JSON(value)
                let friends = json["response"]["profiles"].arrayValue.map { NewsFriends(json: $0) }
                completion?(friends, nil)
            }
        }
    }
}
