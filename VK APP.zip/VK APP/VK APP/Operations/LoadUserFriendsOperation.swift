//
//  LoadUserFriendsOperation.swift
//  VK APP
//
//  Created by Армен Арутюнян on 30/12/2018.
//  Copyright © 2018 Армен Арутюнян. All rights reserved.
//

import Foundation

class LoadUserFriendsOperation: AsynchronousOperation {
    
    let service = VKSesvice()
    var output: [Users]?
    var error: Error?
    
    override func main() {
        loadFriends()
    }
    
    func loadFriends() {
        print(OperationQueue.current?.name ?? "Unknown queue")
        service.loadUserFriendsAlamofire(){ [weak self] (users, error) in
            self?.output = users
            self?.error = error
            self?.state = .finished
        }
    }
}
