//
//  ReloadTableViewOperation.swift
//  VK APP
//
//  Created by Армен Арутюнян on 30/12/2018.
//  Copyright © 2018 Армен Арутюнян. All rights reserved.
//

import UIKit

class ReloadTableViewOperation: Operation {
    
    weak var tableView: UITableView?
    
    init(tableView: UITableView) {
        self.tableView = tableView
    }
    
    override func main() {
        tableView?.reloadData()
    }    
}
