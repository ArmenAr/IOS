//
//  groupsSearchCell.swift
//  VK APP
//
//  Created by Армен Арутюнян on 30.08.2018.
//  Copyright © 2018 Армен Арутюнян. All rights reserved.
//

import UIKit

class GroupsSearchCell: UITableViewCell {

    @IBOutlet weak var groupSearchName: UILabel!
    @IBOutlet weak var groupSearchLogo: UIImageView!
    
    public func configure(with groups: Groups) {
        self.groupSearchLogo.kf.setImage(with: Groups.urlForGroupPhoto(groups.photoString))
        self.groupSearchName.text = groups.name
    }
}
