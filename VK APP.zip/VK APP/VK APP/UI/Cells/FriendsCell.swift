//
//  FriendsCell.swift
//  VK APP
//
//  Created by Армен Арутюнян on 30.08.2018.
//  Copyright © 2018 Армен Арутюнян. All rights reserved.
//

import UIKit
import Kingfisher

class FriendsCell: UITableViewCell {

   
    @IBOutlet weak var friendName: UILabel!
    @IBOutlet weak var friendLogo: UIImageView!
    
    public func configure(with users: Users) {
        self.friendLogo.kf.setImage(with: Users.urlForUserPhoto(users.photoString))
        self.friendName.text = users.firstName
    }
}
