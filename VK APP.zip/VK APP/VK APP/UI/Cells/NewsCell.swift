//
//  NewsCell.swift
//  VK APP
//
//  Created by Армен Арутюнян on 15/11/2018.
//  Copyright © 2018 Армен Арутюнян. All rights reserved.
//

import UIKit
import Kingfisher

class NewsCell: UITableViewCell {

    private var dateFormatter: DateFormatter {
        let dt = DateFormatter()
        dt.dateFormat = "EEEE, HH:mm"
        return dt
    }
    
    @IBOutlet weak var authorLogo: UIImageView!
    @IBOutlet weak var date: UILabel!
    @IBOutlet weak var authorName: UILabel!
    @IBOutlet weak var repostAuthorLogo: UIImageView!
    @IBOutlet weak var repostDate: UILabel!
    @IBOutlet weak var repostAuthorName: UILabel!
    @IBOutlet weak var repostText: UILabel!
    @IBOutlet weak var postText: UILabel!
    @IBOutlet weak var postPhoto: UIImageView!
    @IBOutlet weak var likeCount: UILabel!
    @IBOutlet weak var commentCount: UILabel!
    @IBOutlet weak var repostCount: UILabel!
    @IBOutlet weak var viewsCount: UILabel!
    
    @IBOutlet fileprivate var postPhotoCons: [NSLayoutConstraint]!
    @IBOutlet fileprivate var repostCons: [NSLayoutConstraint]!

    public func configure(with news: News) {

        self.postPhoto.kf.setImage(with: News.urlForNewsPhoto(news.photoString))
        self.postText.text = news.text
        self.repostText.text = news.repostText
        self.commentCount.text = String(news.commentsCount)
        self.likeCount.text = String(news.likesCount)
        self.repostCount.text = String(news.repostCount)
        self.viewsCount.text = String(news.viewsCount)
        let date = Date(timeIntervalSince1970: news.date)
        self.date.text = dateFormatter.string(from: date)
        let repostDate = Date(timeIntervalSince1970: news.repostDate)
        self.repostDate.text = dateFormatter.string(from: repostDate)
    }

    func switchOffRepostAuthorName(with news: News) {
        if news.owner_id == 0 {
            repostCons.forEach {$0.isActive = false}
        } else {
           repostCons.forEach {$0.isActive = true} 
        }
    }
    func switchOffPostFoto(with news: News) {
        guard  postPhotoCons != nil else {return}
        if news.photoString == "" {
            postPhotoCons.forEach {$0.isActive = false}
        } else {
            postPhotoCons.forEach {$0.isActive = true}
        }
    }
    override func prepareForReuse() {
        super.prepareForReuse()
        
    }
}
