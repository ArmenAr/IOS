//
//  groupsCell.swift
//  VK APP
//
//  Created by Армен Арутюнян on 30.08.2018.
//  Copyright © 2018 Армен Арутюнян. All rights reserved.
//

import UIKit
import Kingfisher

class GroupsCell: UITableViewCell {

    @IBOutlet weak var groupLogo: UIImageView!
    
    @IBOutlet weak var groupName: UILabel!
    
    public func configure(with groups: Groups) {
        self.groupLogo.kf.setImage(with: Groups.urlForGroupPhoto(groups.photoString))
        self.groupName.text = groups.name
        
    }
}
