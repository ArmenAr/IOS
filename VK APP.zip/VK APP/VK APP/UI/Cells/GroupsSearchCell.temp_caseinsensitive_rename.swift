//
//  groupsSearchCell.swift
//  VK APP
//
//  Created by Армен Арутюнян on 30.08.2018.
//  Copyright © 2018 Армен Арутюнян. All rights reserved.
//

import UIKit

class GroupsSearchCell: UITableViewCell {

    @IBOutlet weak var groupSearchName: UILabel!
    @IBOutlet weak var groupSearchLogo: UIImageView!
}
