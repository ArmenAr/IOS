//
//  groupsViewController.swift
//  VK APP
//
//  Created by Армен Арутюнян on 30.08.2018.
//  Copyright © 2018 Армен Арутюнян. All rights reserved.
//

import UIKit
import RealmSwift

class GroupsViewController: UITableViewController {
    
    // MARK: - Properties
    
    private var notificationToken: NotificationToken?
    var groups : Results<Groups>?
    let service = VKSesvice()
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        service.loadUserGroupsAlamofire{ [weak self] (groups, error) in
            
            if let error = error {
                print(error.localizedDescription)
            }
            
            guard let groups = groups, let self = self else { return }
            
            Groups.saveGroups(groups)
            
            do {
                self.groups = try Groups.loadGroups()

                DispatchQueue.main.async {
                    self.tableView.reloadData()
                }
            } catch {
                print(error.localizedDescription)
            }
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        notificationToken = self.groups?.observe { [weak self] results in
            switch results {
            case .initial(_):
                self?.tableView.reloadData()
            case .update(_, let deletions, let insertions, let modifications):
                guard let tableView = self?.tableView else { return }
                let operation = ApplyTableViewChanges(tableView: tableView,
                                                      deletions: deletions,
                                                      insertions: insertions,
                                                      updates: modifications)
                OperationQueue.main.addOperation(operation)
            case .error(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    // MARK: - Table view
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return groups?.count ?? 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) ->                 UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "groupsCell", for: indexPath)        as? GroupsCell else {return UITableViewCell()}
        guard let groups = groups else {
            return cell
        }
        cell.configure(with: groups[indexPath.row])
        return cell
    }
}
