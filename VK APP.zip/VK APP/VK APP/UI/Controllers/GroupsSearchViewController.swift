//
//  groupsSearchViewController.swift
//  VK APP
//
//  Created by Армен Арутюнян on 30.08.2018.
//  Copyright © 2018 Армен Арутюнян. All rights reserved.
//

import UIKit

class GroupsSearchViewController: UITableViewController, UISearchBarDelegate {
    @IBOutlet weak var searchBar: UISearchBar!
    
    // MARK: - Properties
    
    var groups = [Groups]()
    let service = VKSesvice()
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // MARK: - Table view

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return groups.count
    }

    func searchBar(_ searchBar : UISearchBar, textDidChange searchText: String) {
        
        service.searchGroupsAlamofire(by: searchText){ [weak self] (groups, error) in
            if let error = error {
                print(error.localizedDescription)
            }
            guard let groups = groups, let self = self else { return }
            
            self.groups = groups
            self.tableView.reloadData()
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "groupsSearchCell", for: indexPath) as? GroupsSearchCell else {return UITableViewCell()}
        cell.configure(with: groups[indexPath.row])
        return cell
    }
}
