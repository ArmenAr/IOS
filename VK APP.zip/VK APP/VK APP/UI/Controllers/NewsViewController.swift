//
//  NewsViewController.swift
//  VK APP
//
//  Created by Армен Арутюнян on 15/11/2018.
//  Copyright © 2018 Армен Арутюнян. All rights reserved.
//

import UIKit
import Kingfisher

class NewsViewController: UITableViewController {

    // MARK: - Properties
    
    var number = 0
    var repostNumber = 0
    let service = VKSesvice()
    var news = [News]()
    var groups = [NewsGroup]()
    var friends = [NewsFriends]()

    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
      
        service.loadNews{[weak self] (news, error) in
            
            if let error = error {
                print(error.localizedDescription)
            }
            
            guard let news = news, let self = self else { return }
            
            self.news = news
            self.tableView.reloadData()
        }
        service.loadNewsGroups{[weak self] (groups, error) in
            
            if let error = error {
                print(error.localizedDescription)
            }
            
            guard let groups = groups, let self = self else { return }
            
            self.groups = groups
            self.tableView.reloadData()
        }
        service.loadNewsFriends{[weak self] (friends, error) in
            
            if let error = error {
                print(error.localizedDescription)
            }
            
            guard let friends = friends, let self = self else { return }
            
            self.friends = friends
            self.tableView.reloadData()
        }

    }

    // MARK: - Table view

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return news.count
    }

    
    fileprivate func repostMethod(_ indexPath: IndexPath, _ cell: NewsCell) {
        if news[indexPath.row].owner_id < 0 {
            repostNumber = -1 * (news[indexPath.row].owner_id)
            for i in 0..<groups.count{
                if groups[i].id == repostNumber{
                    cell.repostAuthorName.text = ("\u{21AA}" + " " + groups[i].name)
                    cell.repostAuthorLogo.kf.setImage(with: NewsGroup.urlForNewsPhoto(groups[i].photoString))
                }
            }
        } else if news[indexPath.row].owner_id > 0 {
            repostNumber = (news[indexPath.row].owner_id)
            for i in 0..<groups.count{
                if groups[i].id == repostNumber{
                    cell.repostAuthorName.text = ("\u{21AA}" + " " + groups[i].name)
                    cell.repostAuthorLogo.kf.setImage(with: NewsGroup.urlForNewsPhoto(groups[i].photoString))
                }
            }
        } else if news[indexPath.row].owner_id == 0 {
            repostNumber = 0
        }
    }
    
    fileprivate func authorsAndGroupsNamesAndLogos(_ indexPath: IndexPath, _ cell: NewsCell) {
        if (news[indexPath.row].source_id) < 0 {
            number = -1 * (news[indexPath.row].source_id)
            for i in 0..<groups.count{
                if groups[i].id == number{
                    cell.authorName.text = groups[i].name
                    cell.authorLogo.kf.setImage(with: NewsGroup.urlForNewsPhoto(groups[i].photoString))
                }
            }
            repostMethod(indexPath, cell)
        } else {
            number = (news[indexPath.row].source_id)
            for i in 0..<friends.count{
                if friends[i].id == number{
                    cell.authorName.text = (friends[i].first_name + " " + friends[i].last_name)
                    cell.authorLogo.kf.setImage(with: NewsFriends.urlForNewsPhoto(friends[i].photoString))
                }
            }
            repostMethod(indexPath, cell)
        }
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "news Cell", for: indexPath) as? NewsCell else {return UITableViewCell()}

        authorsAndGroupsNamesAndLogos(indexPath, cell)
        let cellNews = news[indexPath.row]
        cell.configure(with: cellNews)
        cell.switchOffRepostAuthorName(with: cellNews)
        cell.switchOffPostFoto(with: cellNews)
        
        return cell
    }
}
