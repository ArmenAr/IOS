//
//  FriendsViewController.swift
//  VK APP
//
//  Created by Армен Арутюнян on 30.08.2018.
//  Copyright © 2018 Армен Арутюнян. All rights reserved.
//

import UIKit
import RealmSwift

var userID = 0

class FriendsViewController: UITableViewController {
    
    // MARK: - Properties
    
    private var notificationToken: NotificationToken?
    private var users : Results<Users>?
    let service = VKSesvice()
    let networkQueue = OperationQueue()
    
    // MARK: - Lifecycle

    override func viewDidLoad() {
        super.viewDidLoad()
        
        networkQueue.name = "Network operation"
        networkQueue.maxConcurrentOperationCount = 1
        
        let loadFriendsOperation = LoadUserFriendsOperation()
        loadFriendsOperation.onFinish = { [weak self, weak loadFriendsOperation] in
            if let error = loadFriendsOperation?.error {
                print(error.localizedDescription)
            }
            guard let users = loadFriendsOperation?.output, let self = self else { return }
            Users.saveUsers(users)
            do {
                self.users = try Users.loadFriends()
            } catch {
                print(error.localizedDescription)
            }
        }
        let reloadOperation = ReloadTableViewOperation(tableView: tableView)
        
        reloadOperation.addDependency(loadFriendsOperation)
        
        self.networkQueue.addOperation(loadFriendsOperation)
        OperationQueue.main.addOperation(reloadOperation)
    }
    override func viewWillAppear(_ animated: Bool) {
        notificationToken = self.users?.observe { [weak self] results in
            switch results {
            case .initial(_):
                self?.tableView.reloadData()
            case .update(_, let deletions, let insertions, let modifications):
                self?.tableView.applyChanges(deletions: deletions, insertions: insertions, updates: modifications)
            case .error(let error):
                print(error.localizedDescription)
            }
        }
    }
    
    // MARK: - Table view

    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return users?.count ?? 0
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        userID = users?[indexPath.row].id ?? 0
    }
   
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "FriendsCell", for: indexPath) as? FriendsCell else { return UITableViewCell()}
        guard let users = users else {
            return cell
        }
        cell.configure(with: users[indexPath.row])
        
        return cell
    }
}
