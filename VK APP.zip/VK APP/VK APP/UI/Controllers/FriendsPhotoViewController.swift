
//  friendsPhotoViewController.swift
//  VK APP
//
//  Created by Армен Арутюнян on 30.08.2018.
//  Copyright © 2018 Армен Арутюнян. All rights reserved.
//

import UIKit
import RealmSwift

class FriendsPhotoViewController: UICollectionViewController {

    // MARK: - Properties
    
    public var user = Users()
    private var photo : Results<Photo>?
    private var notificationToken: NotificationToken?
    var photoCell = FriendsPhotoCell()
    let service = VKSesvice()
    
    // MARK: - Lifecycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        self.collectionView!.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "reuseIdentifier")
        service.loadUserPhotoAlamofire(userId: userID){[weak self] (photo, error) in

            if let error = error {
                print(error.localizedDescription)
            }
            
            guard let photo = photo, let self = self else { return }
            
            Photo.savePhoto(photo)
            self.user.photoOwner.append(objectsIn: photo)
            self.user.id = userID
            
            do {
                self.photo = try Photo.loadPhoto()
                self.photo = RealmProvider.get(Photo.self).filter("ownerID = %@", userID)
                DispatchQueue.main.async {
                    self.collectionView.reloadData()
                }
            } catch {
                print(error.localizedDescription)
            }
        }
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        notificationToken = self.photo?.observe {[weak self] changes in
                switch changes {
                case .initial(_):
                    self?.collectionView.reloadData()
                case .update(_, _, _, _):
                    self?.collectionView.reloadData()
                case .error(let error):
                    print(error.localizedDescription)
            }
        }
    }
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        notificationToken?.invalidate()
    }
    
    // MARK: - Collection view
    
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }

    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photo?.count ?? 0
    }

    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "friendsPhotoCell", for: indexPath) as? FriendsPhotoCell else {return UICollectionViewCell()}
        guard let photo = photo else {
            return cell
        }
        cell.configure(with: photo[indexPath.row])
        return cell
    }
}
