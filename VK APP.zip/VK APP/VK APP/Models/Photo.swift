//
//  Photo.swift
//  VK APP
//
//  Created by Армен Арутюнян on 11.10.2018.
//  Copyright © 2018 Армен Арутюнян. All rights reserved.
//

import Foundation
import SwiftyJSON
import RealmSwift

class Photo : Object{
    @objc dynamic var id = 0
    @objc dynamic var photoString = ""
    @objc dynamic var ownerID = userID
    override static func primaryKey() -> String? {
        return "id"
    }
    
    convenience init(json: JSON) {
        self .init()
        
        self.id = json["id"].intValue
        self.photoString = json["sizes"][0]["url"].stringValue
    }
    let photo = LinkingObjects(fromType: Users.self, property: "photoOwner")
}

extension Photo {
    static func add(json: JSON) {
        do {
            let realm = try Realm()

            let photo = Photo(json: json)

            try realm.write {
                realm.add(photo)
            }

        } catch {
            print(error.localizedDescription)
        }
    }
    static func urlForPhoto(_ icon: String) -> URL? {
        return URL(string: "\(icon)")
    }

    
    static func loadPhoto() throws -> Results<Photo> {
        let realm = try Realm()

        return realm.objects(Photo.self)
    }

    @discardableResult
    static func savePhoto(_ photo: [Photo], update: Bool = true) -> Realm {
        
        let config = Realm.Configuration(deleteRealmIfMigrationNeeded: true)
        let realm = try! Realm(configuration: config)
        
        do {
            try realm.write {
                realm.add(photo, update: update)
            }
        } catch {
            print(error.localizedDescription)
        }
        
        return realm
    }
}
