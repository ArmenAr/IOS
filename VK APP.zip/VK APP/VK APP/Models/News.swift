//
//  News.swift
//  VK APP
//
//  Created by Армен Арутюнян on 15/11/2018.
//  Copyright © 2018 Армен Арутюнян. All rights reserved.
//

import Foundation
import SwiftyJSON

class News {
    
    var groups = NewsGroup()
    
    var source_id = 0
    var date = 0.0
    var owner_id = 0
    var text = ""
    var repostText = ""
    var repostDate = 0.0
    var photoString = ""
    var likesCount = 0
    var commentsCount = 0
    var repostCount = 0
    var viewsCount = 0
    var name = ""
    
    convenience init(json: JSON) {
        self .init()
        
        self.source_id = json["source_id"].intValue
        self.date = json["date"].doubleValue
        self.text = json["text"].stringValue
        
        if json["copy_history"][0]["attachments"][0]["type"].stringValue == "" {
            self.photoString = json["attachments"][0]["photo"]["sizes"][3]["url"].stringValue
        } else {
            self.photoString = json["copy_history"][0]["attachments"][0]["photo"]["sizes"][3]["url"].stringValue
            self.repostText = json["copy_history"][0]["text"].stringValue
            self.owner_id = json["copy_history"][0]["owner_id"].intValue
            self.repostDate = json["copy_history"][0]["date"].doubleValue
        }
        self.likesCount = json["likes"]["count"].intValue
        self.commentsCount = json["comments"]["count"].intValue
        self.repostCount = json["reposts"]["count"].intValue
        self.viewsCount = json["views"]["count"].intValue
    }
}

extension News {
    static func urlForNewsPhoto(_ icon: String) -> URL? {
        return URL(string: "\(icon)")
    }
}
class NewsFriends {
    var id = 0
    var first_name = ""
    var last_name = ""
    var photoString = ""
    
    convenience init(json: JSON) {
        self .init()
        self.id = json["id"].intValue
        self.first_name = json["first_name"].stringValue
        self.last_name = json["last_name"].stringValue
        self.photoString = json["photo_100"].stringValue
    }
}
extension NewsFriends {
    static func urlForNewsPhoto(_ icon: String) -> URL? {
        return URL(string: "\(icon)")
    }
}
class NewsGroup  {
    var id = 0
    var name = ""
    var photoString = ""
    
    convenience init(json: JSON) {
        self .init()
        self.id = json["id"].intValue
        self.name = json["name"].stringValue
        self.photoString = json["photo_200"].stringValue
    }
}
extension NewsGroup {
    static func urlForNewsPhoto(_ icon: String) -> URL? {
        return URL(string: "\(icon)")
    }
}
