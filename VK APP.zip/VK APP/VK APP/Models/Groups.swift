//
//  Groups.swift
//  VK APP
//
//  Created by Армен Арутюнян on 11.10.2018.
//  Copyright © 2018 Армен Арутюнян. All rights reserved.
//

import Foundation
import SwiftyJSON
import RealmSwift

class Groups : Object {
    @objc dynamic var id = 0
    @objc dynamic var name = ""
    @objc dynamic var isAdmin = false
    @objc dynamic var isClosed = false
    @objc dynamic var isMember = false
    @objc dynamic var photoString = ""
    
    override static func primaryKey() -> String? {
        return "id"
    }
        
    convenience init(json: JSON) {
        self .init()
        
        self.id = json["id"].intValue
        self.name = json["name"].stringValue
        if json["is_admin"] == 1 {
            self.isAdmin = true
        } else {
            self.isAdmin = false
        }
        if json["is_closed"] == 1 {
            self.isClosed = true
        } else {
            self.isClosed = false
        }
        if json["is_member"] == 1 {
            self.isMember = true
        } else {
            self.isMember = false
        }
        self.photoString = json["photo_100"].stringValue

    }
}
extension Groups {
    static func add(json: JSON) {
        do {
            let realm = try Realm()

            let groups = Groups(json: json)

            try realm.write {
                realm.add(groups)
            }

        } catch {
            print(error.localizedDescription)
        }
    }
    static func urlForGroupPhoto(_ icon: String) -> URL? {
        return URL(string: "\(icon)")
    }

    static func loadGroups() throws -> Results<Groups> {
        let realm = try Realm()

        return realm.objects(Groups.self)
    }

    @discardableResult
    static func saveGroups(_ groups: [Groups], update: Bool = true) -> Realm {
        
        let config = Realm.Configuration(deleteRealmIfMigrationNeeded: true)
        let realm = try! Realm(configuration: config)
        
        do {
            try realm.write {
                realm.add(groups, update: update)
            }
        } catch {
            print(error.localizedDescription)
        }
        
        return realm
    }
}
