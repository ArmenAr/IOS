//
//  Users.swift
//  VK APP
//
//  Created by Армен Арутюнян on 09.10.2018.
//  Copyright © 2018 Армен Арутюнян. All rights reserved.
//

import UIKit
import SwiftyJSON
import RealmSwift

class Users : Object {

    @objc dynamic var id = 0
    @objc dynamic var firstName = ""
    @objc dynamic var lastName = ""
    @objc dynamic var isOnline = false
    @objc dynamic var photoString = ""

    let photoOwner = List<Photo>()
    
    override static func primaryKey() -> String? {
        return "id"
    }
    convenience init(json: JSON, photo : [Photo] = []) {
        self .init()
        
        self.id = json["id"].intValue
        self.firstName = json["first_name"].stringValue
        self.lastName = json["last_name"].stringValue
        if json["online"] == 1 {
            self.isOnline = true
        } else {
            self.isOnline = false
        }
        self.photoString = json["photo_100"].stringValue
    }
    
}
extension Users {
    static func add(json: JSON) {
        do {
            let realm = try Realm()
            
            let user = Users(json: json)
            
            try realm.write {
                realm.add(user)
            }
            
        } catch {
            print(error.localizedDescription)
        }
    }
    static func urlForUserPhoto(_ icon: String) -> URL? {
        return URL(string: "\(icon)")
    }
    
    static func loadFriends() throws -> Results<Users> {
        let realm = try Realm()
        
        return realm.objects(Users.self)
    }
    
    @discardableResult
    static func saveUsers(_ users: [Users], update: Bool = true) -> Realm {

        let config = Realm.Configuration(deleteRealmIfMigrationNeeded: true)
        let realm = try! Realm(configuration: config)


        do {
            try realm.write {
                realm.add(users, update: update)
            }
        } catch {
            print(error.localizedDescription)
        }

        return realm
    }
}
