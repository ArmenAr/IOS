//
//  DataBase.swift
//  TaxiMap
//
//  Created by Армен Арутюнян on 16/02/2019.
//  Copyright © 2019 Армен Арутюнян. All rights reserved.
//

import Foundation

class DataBase {
    let destination = [("Воробьевы горы", 55.709378, 37.542214),
                       ("Красная площадь", 55.753595, 37.621031),
                       ("МГУ Им. М.В. Ломоносова", 55.702929, 37.530782),
                       ("Парк 60 лет октября", 55.656219, 37.399036),
                       ("Пушкинский музей", 55.743525, 37.597417),
                       ("Третьяковская галерея", 55.741392, 37.620522),
                       ("Храм Христа Спасителя", 55.744761, 37.604891),
                       ("Царицынский Парк", 55.615593, 37.688837),
                       ("Mail.ru Group", 55.797026, 37.537916),
                       ("Yandex", 55.733842, 37.588144)]
}

class AddressDataSource {
    
    var filteredItems: [(String, Double, Double)] = []
    var searchText = "" {
        didSet {
            searchTextDidChange()
        }
    }
    
    let addresses = DataBase().destination
    
    
    
    private func searchTextDidChange() {
        if searchText.isEmpty {
            filteredItems = addresses
            return
        }
        let lowecasedText = searchText.lowercased()
        filteredItems = addresses.filter { $0.0.lowercased().hasPrefix(lowecasedText) }
    }
    
}
