//
//  LocationService.swift
//  TaxiMap
//
//  Created by Армен Арутюнян on 09/02/2019.
//  Copyright © 2019 Армен Арутюнян. All rights reserved.
//

import MapKit
import CoreLocation

protocol LocationServiceDelegate: AnyObject {
    
    func locationServiceDidReceiveLocationPermission()
    
    func locationServiceDidUpdateRegion(_ region: MKCoordinateRegion)
    
    func locationServiceDidUpdateLocation(_ location: CLLocationCoordinate2D)
    
}

class LocationService: NSObject {
    
    let dataBase = DataBase().destination
    let locationManager = CLLocationManager()
    let regionInMetters: Double = 20000
    weak var delegate: LocationServiceDelegate?
    var location = CLLocationCoordinate2D()
    
    func requestLocationAuthorization() {
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyBest

        guard CLLocationManager.locationServicesEnabled() else { return }
        switch CLLocationManager.authorizationStatus() {
        case .authorizedWhenInUse, .authorizedAlways:
            didReceiveLocationPermission()
        case .notDetermined:
            locationManager.requestWhenInUseAuthorization()
        case .denied, .restricted:
            break
        }
    }
    
    func didReceiveLocationPermission() {
        delegate?.locationServiceDidReceiveLocationPermission()
        locationManager.startUpdatingLocation()
    }
    
    func currentRegion() -> MKCoordinateRegion? {
        guard let location = locationManager.location?.coordinate else { return nil }
        
        return MKCoordinateRegion(center: location,
                                  latitudinalMeters: regionInMetters,
                                  longitudinalMeters: regionInMetters)
    }
    
    func setNewLocation(map: MKMapView,index: Int) {
    
        map.removeAnnotations(map.annotations)
        let location = CLLocationCoordinate2D(latitude: dataBase[index].1, longitude: dataBase[index].2)
        let annotation = MKPointAnnotation()
        annotation.coordinate = location
        annotation.title = dataBase[index].0
        
        map.addAnnotation(annotation)
    }

    func deleteOldLocation(map: MKMapView,index: Int) {
        
        let location = CLLocationCoordinate2D(latitude: dataBase[index].1, longitude: dataBase[index].2)
        let annotation = MKPointAnnotation()
        annotation.coordinate = location
        
        map.removeAnnotation(annotation)
    }
}

extension LocationService: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        let region = MKCoordinateRegion(center: center, latitudinalMeters: regionInMetters, longitudinalMeters: regionInMetters)
        self.location = location.coordinate
        delegate?.locationServiceDidUpdateLocation(self.location)
        delegate?.locationServiceDidUpdateRegion(region)
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .authorizedAlways, .authorizedWhenInUse:
            didReceiveLocationPermission()
        default:
            break
        }
    }
}
