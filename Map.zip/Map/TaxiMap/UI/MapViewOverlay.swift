//
//  MapViewOverlay.swift
//  TaxiMap
//
//  Created by Армен Арутюнян on 09/02/2019.
//  Copyright © 2019 Армен Арутюнян. All rights reserved.
//

import UIKit

protocol MapViewOverlayDelegate: AnyObject {

	func mapViewOverlay(_ overlay: MapViewOverlay, didSelectAddressAt index: Int)
    
    func buttonDidSelected(didSelectbutton alert: UIAlertController)

}

class MapViewOverlay: UIView {
    
    @IBOutlet weak var tapView: TapView!
    @IBOutlet weak var fromLabel: UILabel!
    @IBOutlet var toTextField: UITextField!
    @IBOutlet var addressListTableView: UITableView!
    @IBOutlet var doneButton: UIButton!

	weak var delegate: MapViewOverlayDelegate?

    let dataSource = AddressDataSource()
    var textFieldObserver: AnyObject?
    var selectedAddress: String?
    var index = -1
    let dataBase = DataBase().destination
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        toTextField.delegate = self
        addressListTableView.isHidden = true
        addressListTableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        addressListTableView.dataSource = self
        addressListTableView.delegate = self
        addressListTableView.rowHeight = UITableView.automaticDimension
        addressListTableView.estimatedRowHeight = 100
        updateDoneButtonState()
        beginObservingTextFieldChanges()
    }
    
    private func beginObservingTextFieldChanges() {
        guard textFieldObserver == nil else { return }
        textFieldObserver = NotificationCenter.default.addObserver(forName: UITextField.textDidChangeNotification,
                                                                   object: toTextField,
                                                                   queue: .main,
                                                                   using: { [weak self] (notification) in
                                                                    self?.textFieldDidChange(notification)
        })
    }
    
    private func textFieldDidChange(_ notification: Notification) {
        selectedAddress = nil
        updateDoneButtonState()
        updateSearch(text: toTextField.text ?? "")
    }
    
    private func updateSearch(text: String) {
        dataSource.searchText = text
        addressListTableView.reloadData()
    }
    
    private func updateDoneButtonState() {
        doneButton.isEnabled = selectedAddress != nil
    }

    @IBAction func doneButton(_ sender: Any) {
        let alertController = UIAlertController(title: "Ваш заказ Принят", message: "Машина будет в течении 10 минут", preferredStyle: .alert)
        let action = UIAlertAction(title: "Ок", style: .default, handler: nil)
        alertController.addAction(action)
        delegate?.buttonDidSelected(didSelectbutton: alertController)
    }
    
}

extension MapViewOverlay: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.filteredItems.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let result = dataSource.filteredItems[indexPath.row].0
        cell.textLabel?.text = result
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let address = dataSource.filteredItems[indexPath.row].0
        userDidSelectNewAddress(address)
        index = dataBase.index{$0.0 == address} ?? -1
		delegate?.mapViewOverlay(self, didSelectAddressAt: index)
    }
    
    func userDidSelectNewAddress(_ address: String) {
        selectedAddress = address
        toTextField.text = selectedAddress
        updateDoneButtonState()
        toTextField.resignFirstResponder()
        addressListTableView.isHidden = true
    }
    
}

extension MapViewOverlay: UITextFieldDelegate {
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        addressListTableView.isHidden = false
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        if textField.text?.isEmpty == true {
            addressListTableView.isHidden = true
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
}

class TapView: UIView {

    override func awakeFromNib() {
        super.awakeFromNib()
        self.hideKeyboard()
    }
    
}

extension TapView {
    
    func hideKeyboard() {
        
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(TapView.dismissKeyboard))
        
        self.addGestureRecognizer(tap)
    }
    
    @objc func dismissKeyboard() {
        self.endEditing(true)
    }
}
