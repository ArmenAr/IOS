//
//  ViewController.swift
//  TaxiMap
//
//  Created by Армен Арутюнян on 04/02/2019.
//  Copyright © 2019 Армен Арутюнян. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class MapViewController: UIViewController {
    
    @IBOutlet weak var map: MKMapView!
    
    var someView = MapViewOverlay()
    let locationService = LocationService()
    let keyboard = Keyboard()
    let dataBase = DataBase().destination
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        requestLocationAuthorizaion()
        addOverlay()
        keyboard.startObservingKeyboard(self.view)
      
    }
    
    func requestLocationAuthorizaion() {
        locationService.delegate = self
        locationService.requestLocationAuthorization()
    }
    
    func addOverlay() {
        let nib = UINib(nibName: "MapViewOverlay", bundle: nil)
        guard let overlay = nib.instantiate(withOwner: nil, options: nil).first as? MapViewOverlay else {
            fatalError("failed to load view from nib")
        }
        overlay.translatesAutoresizingMaskIntoConstraints = false

		overlay.delegate = self

        someView = overlay
        view.addSubview(someView)
        
        NSLayoutConstraint.activate([
            view.leadingAnchor.constraint(equalTo: overlay.leadingAnchor),
            view.trailingAnchor.constraint(equalTo: overlay.trailingAnchor),
            view.bottomAnchor.constraint(equalTo: overlay.bottomAnchor),
            overlay.heightAnchor.constraint(equalTo: view.heightAnchor, multiplier: 0.3)
            ])
        
        addPanGesture(view: someView)

    }
    
    func addPanGesture(view: UIView) {
        let pan = UIPanGestureRecognizer(target: self, action: #selector (self.handlePenGesture))
        view.addGestureRecognizer(pan)
    }
    @objc func handlePenGesture(recognizer: UIPanGestureRecognizer){
        
        if recognizer.state == .changed {
            
            let translation = recognizer.translation(in: self.view)
            
            someView.frame.size.height -= translation.y
            someView.frame.origin.y += translation.y
            
            recognizer.setTranslation(CGPoint.zero, in: self.view)
            
        } else if recognizer.state == .ended {
            if someView.frame.size.height > (self.view.frame.size.height / 2) {
                someView.frame.size.height = self.view.frame.size.height
                someView.frame.origin.y = 0
                
            } else {
                someView.frame.size.height = self.view.frame.size.height / 3
                someView.frame.origin.y = self.view.frame.size.height * 0.7
            }
            
        }
        
    }
    
}

extension MapViewController: LocationServiceDelegate {
    func locationServiceDidUpdateLocation(_ location: CLLocationCoordinate2D) {
        someView.fromLabel.text = "Your cordinate: Latitude \(String(locationService.location.latitude)) Longitude \(String(locationService.location.longitude))"
        
    }
    
    func locationServiceDidReceiveLocationPermission() {
        map.showsUserLocation = true
    }
    
    func locationServiceDidUpdateRegion(_ region: MKCoordinateRegion) {
        map.setRegion(region, animated: true)
    }
    
}

extension MapViewController: MapViewOverlayDelegate {
    func buttonDidSelected(didSelectbutton alert: UIAlertController) {
        self.present(alert, animated: true, completion: nil)
    }
    
	func mapViewOverlay(_ overlay: MapViewOverlay, didSelectAddressAt index: Int) {
		guard index > -1 else { return }
		locationService.setNewLocation(map: map, index: index)
	}

}
