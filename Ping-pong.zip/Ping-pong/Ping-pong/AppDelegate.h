//
//  AppDelegate.h
//  Ping-pong
//
//  Created by Армен Арутюнян on 02/02/2019.
//  Copyright © 2019 Армен Арутюнян. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

